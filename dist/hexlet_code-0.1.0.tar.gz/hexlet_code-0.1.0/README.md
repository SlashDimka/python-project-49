### Hexlet tests and linter status:
[![Actions Status](https://github.com/SlashDimka/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SlashDimka/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/9bb653b237c0ff8725e8/maintainability)](https://codeclimate.com/github/SlashDimka/python-project-49/maintainability)
###Hello my name Dmitry Korolkov
