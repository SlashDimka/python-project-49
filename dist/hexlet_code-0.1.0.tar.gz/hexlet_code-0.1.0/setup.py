# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SlashDimka/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SlashDimka/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/9bb653b237c0ff8725e8/maintainability)](https://codeclimate.com/github/SlashDimka/python-project-49/maintainability)\n\n# Brain games\n## This repository is made by Dmitry Korolkov, a student of Hexlet educational project. It contains a project called "Brain games" which includes five mathematical textual games \n\n# Requirements\n## Python 3.10 or above\n\n# Installation\n## Use following commands for installing:\n\n### poetry install\n### poetry build\n### poetry publish\n### python3 -m pip install dist/*.whl\n==========================================================================\n### asciinema\n### brain-even\n[![asciicast](https://asciinema.org/a/ZYNTd037lV6sewj101KTyHM0U.svg)](https://asciinema.org/a/ZYNTd037lV6sewj101KTyHM0U)\n### brain-calc\n[![asciicast](https://asciinema.org/a/tsk4XhVeyMBhbxps8cOvkPVOb.svg)](https://asciinema.org/a/tsk4XhVeyMBhbxps8cOvkPVOb)\n### brain-gcd\n[![asciicast](https://asciinema.org/a/UsJSeSEksf8IDk0Jq5ylwZMV9.svg)](https://asciinema.org/a/UsJSeSEksf8IDk0Jq5ylwZMV9)\n### brain-progression\n[![asciicast](https://asciinema.org/a/gd7OzDzDFlSD4BRxvSUIjqOVa.svg)](https://asciinema.org/a/gd7OzDzDFlSD4BRxvSUIjqOVa)\n### brain-prime\n[![asciicast](https://asciinema.org/a/TGKSVrI6oyKogJ7m9XIlExiLd.svg)](https://asciinema.org/a/TGKSVrI6oyKogJ7m9XIlExiLd)\n\n',
    'author': 'SlashDimka',
    'author_email': 'korolkovpro@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
